--Trigger list for Caucasus SP

--INIT SCRIPTS START

sp("USA AWACS")
sp("TANKERUS")
sp("TANKERUK")
ctld.activatePickupZone("pickzone1")

-- JTACAutoLase('JTAC-AG1', 1688, true,"all" )
-- JTACAutoLase('JTAC-AG2', 1688, true,"all" )
-- JTACAutoLase('JTAC-AG3', 1688, true,"all" )
-- JTACAutoLase('JTAC-AG4', 1688, true,"all" )
-- JTACAutoLase('JTAC-AG5', 1688, true,"all" )

-- JTACAutoLase('JTAC-MR1', 1688, true,"all" )
-- JTACAutoLase('JTAC-MR2', 1688, true,"all" )
-- JTACAutoLase('JTAC-MR3', 1688, true,"all" )
-- JTACAutoLase('JTAC-MR4', 1688, true,"all" )
-- JTACAutoLase('JTAC-MR5', 1688, true,"all" )

-- JTACAutoLase('JTAC-AGH1', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH2', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH3', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH4', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH5', 1688, true,"all" )

-- JTACAutoLase('JTAC-AGH6', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH7', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH8', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH9', 1688, true,"all" )
-- JTACAutoLase('JTAC-AGH10', 1688, true,"all" )

JTACAutoLase('JTAC-AG1', 1688 )
JTACAutoLase('JTAC-AG2', 1688 )
JTACAutoLase('JTAC-AG3', 1688 )
JTACAutoLase('JTAC-AG4', 1688 )
JTACAutoLase('JTAC-AG5', 1688 )

JTACAutoLase('JTAC-MR1', 1688 )
JTACAutoLase('JTAC-MR2', 1688 )
JTACAutoLase('JTAC-MR3', 1688 )
JTACAutoLase('JTAC-MR4', 1688 )
JTACAutoLase('JTAC-MR5', 1688 )

JTACAutoLase('JTAC-AGH1', 1688 )
JTACAutoLase('JTAC-AGH2', 1688 )
JTACAutoLase('JTAC-AGH3', 1688 )
JTACAutoLase('JTAC-AGH4', 1688 )
JTACAutoLase('JTAC-AGH5', 1688 )

JTACAutoLase('JTAC-AGH6', 1688 )
JTACAutoLase('JTAC-AGH7', 1688 )
JTACAutoLase('JTAC-AGH8', 1688 )
JTACAutoLase('JTAC-AGH9', 1688 )
JTACAutoLase('JTAC-AGH10', 1688 )

local function main()
timer.scheduleFunction(main, {}, timer.getTime() + 1)  


----------AIR MISSIONS!-----------------------------------------------------------
--a2a easy
if trigger.misc.getUserFlag('1') == 1 then
	trigger.action.outText( "<< A2A [Easy] Mission Active >>", 7)
	trigger.action.outSound("AC04 Beep.ogg" )
	a2a_easy_start()
	trigger.action.setUserFlag('1', false)
end

--a2a normal
if trigger.misc.getUserFlag('2') == 1 then
	trigger.action.outText( "<< A2A [Normal] Mission Active >>", 7)
	trigger.action.outSound("AC04 Beep.ogg" )
	a2a_norm_start()
	trigger.action.setUserFlag('2', false)
end

--a2a hard
if trigger.misc.getUserFlag('3') == 1 then
	trigger.action.outText( "<< A2A [Hard] Mission Active >>", 7)
	trigger.action.outSound("AC04 Beep.ogg" )
	a2a_hard_start()
	trigger.action.setUserFlag('3', false)
end

--a2a random
if trigger.misc.getUserFlag('4') == 1 then
	trigger.action.outText( "<< A2A [Random] Mission Active >>", 7)
	trigger.action.outSound("AC04 Beep.ogg" )
	a2a_all_start()
	trigger.action.setUserFlag('4', false)
end

----------Ground missions!-----------------------------------------------------------

--a2g hard
if trigger.misc.getUserFlag('61') == 1 then
	trigger.action.outText( "<< A2G Hard Mission Active >>", 7)
	trigger.action.outSound("Ui beep.ogg" )
	a2gj_start()
	trigger.action.setUserFlag('61', false)
end

--a2g easy
if trigger.misc.getUserFlag('71') == 1 then
	trigger.action.outText( "<< A2G Easy (Multirole) Mission Active >>", 7)
	trigger.action.outSound("Ui beep.ogg" )
	a2gmr_start()
	trigger.action.setUserFlag('71', false)
end

--a2g helo
if trigger.misc.getUserFlag('81') == 1 then
	trigger.action.outText( "<< A2G Helo Mission Active >>", 7)
	trigger.action.outSound("Ui beep.ogg" )
	a2gh_start()
	trigger.action.setUserFlag('81', false)
end

--a2g ia
if trigger.misc.getUserFlag('111') == 1 then
	trigger.action.outText( "<< A2G Helo Infantry Assault Mission Active >>", 7)
	trigger.action.outSound("Ui beep.ogg" )
	a2gia_start()
	trigger.action.setUserFlag('111', false)
end

--a2g as
if trigger.misc.getUserFlag('91') == 1 then
	trigger.action.outText( "<< Anti-Ship Mission Active >>", 7)
	trigger.action.outSound("Ui beep.ogg" )
	a2gas_start()
	trigger.action.setUserFlag('91', false)
end


----------DEBUG!-----------------------------------------------------------


--AWACS
if trigger.misc.getUserFlag('50') == 1 then
	trigger.action.outText( "<< AWACS Reset >>", 7)
	sp("USA AWACS")
	trigger.action.setUserFlag('50', false)
end

if trigger.misc.getUserFlag('51') == 1 then
	trigger.action.outText( "<< Tankers Reset >>", 7)
	sp("TANKERUS")
	sp("TANKERUK")
	trigger.action.setUserFlag('51', false)
end


end
main()



MR = {}
MR.Text1 = "---INTEL---> GROUND UNITS at GRID FJ75 [A2G Easy Mission 1] [Auto LS. 1688]"
MR.Text2 = "---INTEL---> GROUND UNITS at GRID FH66 [A2G Easy Mission 2] [Auto LS. 1688]"
MR.Text3 = "---INTEL---> GROUND UNITS at GRID GG48 [A2G Easy Mission 3] [Auto LS. 1688]"
MR.Text4 = "---INTEL---> GROUND UNITS at GRID EJ90 [A2G Easy Mission 4] [Auto LS. 1688]"
MR.Text5 = "---INTEL---> GROUND UNITS at GRID GH31 [A2G Easy Mission 5] [Auto LS. 1688]"


AG = {}
AG.Text1 = "---INTEL---> GROUND UNITS at GRID GH12 [A2G Hard Mission 1] [Auto LS. 1688]"
AG.Text2 = "---INTEL---> GROUND UNITS at GRID EJ81 [A2G Hard Mission 2] [Auto LS. 1688]"
AG.Text3 = "---INTEL---> GROUND UNITS at GRID GJ21 [A2G Hard Mission 3] [Auto LS. 1688]"
AG.Text4 = "---INTEL---> GROUND UNITS at GRID GG19 [A2G Hard Mission 4] [Auto LS. 1688]"
AG.Text5 = "---INTEL---> GROUND UNITS at GRID FH74 [A2G Hard Mission 5] [Auto LS. 1688]"



AGH = {}
AGH.Text1 = "---INTEL---> GROUND UNITS at GRID FH08 [A2G Helo/Infantry Assault Mission 1]"
AGH.Text2 = "---INTEL---> GROUND UNITS at GRID FH38 [A2G Helo/Infantry Assault Mission 2]"
AGH.Text3 = "---INTEL---> GROUND UNITS at GRID FH47 [A2G Helo/Infantry Assault Mission 3]"
AGH.Text4 = "---INTEL---> GROUND UNITS at GRID FH19 [A2G Helo/Infantry Assault Mission 4]"
AGH.Text5 = "---INTEL---> GROUND UNITS at GRID FH66 [A2G Helo/Infantry Assault Mission 5]"

AGH.Text6 = "---INTEL---> GROUND UNITS at GRID FH08 [A2G Helo/Infantry Assault Mission 6]"
AGH.Text7 = "---INTEL---> GROUND UNITS at GRID FH48 [A2G Helo/Infantry Assault Mission 7]"
AGH.Text8 = "---INTEL---> GROUND UNITS at GRID FH67 [A2G Helo/Infantry Assault Mission 8]"
AGH.Text9 = "---INTEL---> GROUND UNITS at GRID FH59 [A2G Helo/Infantry Assault Mission 9]"
AGH.Text10 = "---INTEL---> GROUND UNITS at GRID FH21 [A2G Helo/Infantry Assault Mission 10]"


AS = {}
AS.Text1 = "---INTEL---> NAVAL UNITS at GRID EG46 [Anti-Ship Mission 1]"
AS.Text2 = "---INTEL---> NAVAL UNITS at GRID EH34 [Anti-Ship Mission 2]"
AS.Text3 = "---INTEL---> NAVAL UNITS at GRID FH01 [Anti-Ship Mission 3]"
AS.Text4 = "---INTEL---> NAVAL UNITS at GRID FG14 [Anti-Ship Mission 4]"
AS.Text5 = "---INTEL---> NAVAL UNITS at GRID FG66 [Anti-Ship Mission 5]"

function main_intel()
timer.scheduleFunction(main_intel, {}, timer.getTime() + 1)  




--INTEL TRIGGERS!!!!------------------------------------------------------


if trigger.misc.getUserFlag('100') == 1 then
trigger.action.outText( "LOCATION INTEL REQUEST:\n \nDisplaying active ground attack missions (if any are available)", 8)
end


if trigger.misc.getUserFlag('800') == 1 then
trigger.action.outText( "---> SMOKE/FLARES DEPLOYED AT ALL ACTIVE A2G ZONES.", 8)
end



--to initialize JTACs
trigger.action.setUserFlag('90002', true)

if 
trigger.misc.getUserFlag('100') == 1 or 
trigger.misc.getUserFlag('800') == 1 or
trigger.misc.getUserFlag('90002') == 1 
then

--START ZONE COPY
 _zone = trigger.misc.getZone("MR1")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( MR.Text1, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-MR1"):activate()
         trigger.action.setUserFlag('MR1-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('MR1-Inside') == 1  then			
					trigger.action.outText( "<< A2G Easy Mission 1 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('MR1-Inside', false)					
					trigger.action.setUserFlag('MR-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("MR2")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( MR.Text2, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-MR2"):activate()
         trigger.action.setUserFlag('MR2-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('MR2-Inside') == 1  then			
					trigger.action.outText( "<< A2G Easy Mission 2 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('MR2-Inside', false)					
					trigger.action.setUserFlag('MR-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("MR3")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( MR.Text3, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-MR3"):activate()
         trigger.action.setUserFlag('MR3-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('MR3-Inside') == 1  then			
					trigger.action.outText( "<< A2G Easy Mission 1 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('MR3-Inside', false)					
					trigger.action.setUserFlag('MR-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("MR4")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( MR.Text4, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-MR4"):activate()
         trigger.action.setUserFlag('MR4-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('MR4-Inside') == 1  then			
					trigger.action.outText( "<< A2G Easy Mission 4 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('MR4-Inside', false)					
					trigger.action.setUserFlag('MR-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("MR5")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( MR.Text5, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-MR5"):activate()
         trigger.action.setUserFlag('MR5-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('MR5-Inside') == 1  then			
					trigger.action.outText( "<< A2G Easy Mission 5 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('MR5-Inside', false)					
					trigger.action.setUserFlag('MR-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AG1")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AG.Text1, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AG1"):activate()
         trigger.action.setUserFlag('AG1-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AG1-Inside') == 1  then			
					trigger.action.outText( "<< A2G Hard Mission 1 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AG1-Inside', false)					
					trigger.action.setUserFlag('AG-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AG2")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AG.Text2, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AG2"):activate()
         trigger.action.setUserFlag('AG2-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AG2-Inside') == 1  then			
					trigger.action.outText( "<< A2G Hard Mission 2 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AG2-Inside', false)					
					trigger.action.setUserFlag('AG-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AG3")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AG.Text3, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AG3"):activate()
         trigger.action.setUserFlag('AG3-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AG3-Inside') == 1  then			
					trigger.action.outText( "<< A2G Hard Mission 3 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AG3-Inside', false)					
					trigger.action.setUserFlag('AG-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AG4")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AG.Text4, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AG4"):activate()
         trigger.action.setUserFlag('AG4-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AG4-Inside') == 1  then			
					trigger.action.outText( "<< A2G Hard Mission 4 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AG4-Inside', false)					
					trigger.action.setUserFlag('AG-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AG5")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AG.Text5, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AG5"):activate()
         trigger.action.setUserFlag('AG5-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AG5-Inside') == 1  then			
					trigger.action.outText( "<< A2G Hard Mission 5 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AG5-Inside', false)					
					trigger.action.setUserFlag('AG-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH1")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text1, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH1"):activate()
         trigger.action.setUserFlag('AGH1-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH1-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 1 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH1-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH2")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text2, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH2"):activate()
         trigger.action.setUserFlag('AGH2-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH1-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 2 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH2-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH3")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text3, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH3"):activate()
         trigger.action.setUserFlag('AGH3-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH3-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 3 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH3-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH4")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text4, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH4"):activate()
         trigger.action.setUserFlag('AGH4-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH4-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 4 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH4-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH5")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text5, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH5"):activate()
         trigger.action.setUserFlag('AGH5-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH5-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 5 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH5-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH6")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text6, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH6"):activate()
         trigger.action.setUserFlag('AGH6-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH6-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 6 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH6-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH7")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text7, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH7"):activate()
         trigger.action.setUserFlag('AGH7-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH7-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 7 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH7-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH8")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text8, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH8"):activate()
         trigger.action.setUserFlag('AGH8-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH8-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 8 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH8-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH9")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text9, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH9"):activate()
         trigger.action.setUserFlag('AGH9-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH9-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 9 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH9-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("AGH10")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 914  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AGH.Text10, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         Group.getByName("JTAC-AGH10"):activate()
         trigger.action.setUserFlag('AGH10-Inside', true)
		 end

		  if _foundRed and trigger.misc.getUserFlag('800') == 1  then			
					trigger.action.smoke  (_zone.point, 2)
					trigger.action.signalFlare(_zone.point, 1, 0 )					 
		 end

		  if not _foundRed and trigger.misc.getUserFlag('AGH10-Inside') == 1  then			
					trigger.action.outText( "<< A2G Helo Mission 10 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('AGH10-Inside', false)					
					trigger.action.setUserFlag('AGH-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("ASS1")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 3000  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AS.Text1, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         trigger.action.setUserFlag('ASS1-Inside', true)
		 end

		  if not _foundRed and trigger.misc.getUserFlag('ASS1-Inside') == 1  then			
					trigger.action.outText( "<< Anti-Ship Mission 1 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('ASS1-Inside', false)					
					trigger.action.setUserFlag('AS-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("ASS2")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 3000  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AS.Text2, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         trigger.action.setUserFlag('ASS2-Inside', true)
		 end

		  if not _foundRed and trigger.misc.getUserFlag('ASS2-Inside') == 1  then			
					trigger.action.outText( "<< Anti-Ship Mission 2 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('ASS2-Inside', false)					
					trigger.action.setUserFlag('AS-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("ASS3")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 3000  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AS.Text3, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         trigger.action.setUserFlag('ASS3-Inside', true)
		 end

		  if not _foundRed and trigger.misc.getUserFlag('ASS3-Inside') == 1  then			
					trigger.action.outText( "<< Anti-Ship Mission 1 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('ASS3-Inside', false)					
					trigger.action.setUserFlag('AS-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("ASS4")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 3000  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AS.Text4, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         trigger.action.setUserFlag('ASS4-Inside', true)
		 end

		  if not _foundRed and trigger.misc.getUserFlag('ASS4-Inside') == 1  then			
					trigger.action.outText( "<< Anti-Ship Mission 4 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('ASS4-Inside', false)					
					trigger.action.setUserFlag('AS-STARTING', false)					
		 end
--END ZONE PASTE

--START ZONE COPY
 _zone = trigger.misc.getZone("ASS5")

            _zone.point = mist.utils.makeVec3GL(_zone.point)
            _zone.point.y = _zone.point.y + 1 -- offset center by 10KM
             _volume = {
                id = world.VolumeType.SPHERE,
                params = {
                    point = _zone.point, 
                    radius = 3000  -- radius in meters from the size of the zone
                }
            }
             _foundRed = false
--             _foundBlue = true
             _search = function(_unit, _coa)
                pcall(function()        
                    if _unit ~= nil
                            and _unit:isExist()
                            and _unit:isActive()
                            and _unit:getLife() > 0
                             then
                        if _unit:getCoalition() == 1 then
                            _foundRed = true
                        else
                            _foundBlue = true
                        end
                    end
                end)
                return true
            end
            world.searchObjects(Object.Category.UNIT, _volume, _search)
         
		 if _foundRed and trigger.misc.getUserFlag('100') == 1  then
						trigger.action.outText( AS.Text5, 40)
       		 end
			 
--SPAWN JTAC		 
 		 if _foundRed  then
         trigger.action.setUserFlag('ASS5-Inside', true)
		 end

		  if not _foundRed and trigger.misc.getUserFlag('ASS5-Inside') == 1  then			
					trigger.action.outText( "<< Anti-Ship Mission 5 Complete >>", 5)
					trigger.action.outSound("Hi-Tech Xbox Alert.ogg" )
					trigger.action.setUserFlag('ASS5-Inside', false)					
					trigger.action.setUserFlag('AS-STARTING', false)					
		 end
--END ZONE PASTE


end

trigger.action.setUserFlag('100', false)
trigger.action.setUserFlag('800', false)

--to initialize JTACs
trigger.action.setUserFlag('90002', false)



end
main_intel()


--a2g jet
function a2gj_text_start()
trigger.action.outText( "<< Air to Ground Hard Mission Initializing >>", 10)
trigger.action.outSound( "radio click.ogg" )
trigger.action.setUserFlag('61', true)
trigger.action.setUserFlag('6', false)
trigger.action.setUserFlag('AG-STARTING', true)
end

function a2gj_text_fail()
trigger.action.outText( "<< There is already a mission of this type currently active. >>\n \nYou can only spawn one of each A2G mission type at a time.\n \nPlease complete this mission type before spawning a new one.", 10)
trigger.action.outSound( "BD_00006 back square.ogg" )
trigger.action.setUserFlag('6', false)
end

--MR
function mr_text_start()
trigger.action.outText( "<< Air to Ground Easy Mission Initializing >>", 10)
trigger.action.outSound( "radio click.ogg" )
trigger.action.setUserFlag('71', true)
trigger.action.setUserFlag('7', false)
trigger.action.setUserFlag('MR-STARTING', true)
end



function mr_text_fail()
trigger.action.outText( "<< There is already a mission of this type currently active. >>\n \nYou can only spawn one of each A2G mission type at a time.\n \nPlease complete this mission type before spawning a new one.", 10)
trigger.action.outSound( "BD_00006 back square.ogg" )
trigger.action.setUserFlag('7', false)
end

--helo
function a2gh_text_start()
trigger.action.outText( "<< Air to Ground Mission [Helos] Initializing >>", 10)
trigger.action.outSound( "radio click.ogg" )
trigger.action.setUserFlag('81', true)
trigger.action.setUserFlag('8', false)
trigger.action.setUserFlag('AGH-STARTING', true)
end


function a2gh_text_fail()
trigger.action.outText( "<< There is already a mission of this type currently active. >>\n \nYou can only spawn one of each A2G mission type at a time.\n \nPlease complete this mission type before spawning a new one.", 10)
trigger.action.outSound( "BD_00006 back square.ogg" )
trigger.action.setUserFlag('8', false)
end

--helo ia
function a2gia_text_start()
trigger.action.setUserFlag('10', false)
trigger.action.setUserFlag('AGH-STARTING', true)
trigger.action.outText( "<< Infantry Assault Mission [Helos] Initializing >>", 10)
trigger.action.outSound( "radio click.ogg" )
trigger.action.setUserFlag('111', true)
end

function a2gia_text_fail()
trigger.action.outText( "<< There is already a mission of this type currently active. >>\n \nYou can only spawn one of each A2G mission type at a time.\n \nPlease complete this mission type before spawning a new one.", 10)
trigger.action.outSound( "BD_00006 back square.ogg" )
trigger.action.setUserFlag('10', false)
end

--as
function a2gas_text_start()
trigger.action.outText( "<< Anti-Ship Mission Initializing >>", 10)
trigger.action.outSound( "radio click.ogg" )
trigger.action.setUserFlag('91', true)
trigger.action.setUserFlag('9', false)
trigger.action.setUserFlag('AS-STARTING', true)
end

function a2gas_text_fail()
trigger.action.outText( "<< There is already a mission of this type currently active. >>\n \nYou can only spawn one of each A2G mission type at a time.\n \nPlease complete this mission type before spawning a new one.", 10)
trigger.action.outSound( "BD_00006 back square.ogg" )
trigger.action.setUserFlag('9', false)
end

trigger.action.setUserFlag('INIT_TIME', true)
trigger.action.setUserFlag('MISSONS_START_COMPLETE', true)

if trigger.misc.getUserFlag('INIT_TIME') == 1 then

	timer.scheduleFunction(function() 
	trigger.action.outText(	"<< Mission Tasking/Spawning Menu Added to your F10 - Other Menu >>", 15)
	end, nil, timer.getTime() + 5   )
	
end




local function main_start_missions()
timer.scheduleFunction(main_start_missions, {}, timer.getTime() + 1 )  

if trigger.misc.getUserFlag('MISSONS_START_COMPLETE') == 1 then

--MR Manual
if
trigger.misc.getUserFlag('MR-STARTING') == 0 and
trigger.misc.getUserFlag('MR1-Inside') == 0 and
trigger.misc.getUserFlag('MR2-Inside') == 0 and
trigger.misc.getUserFlag('MR3-Inside') == 0 and
trigger.misc.getUserFlag('MR4-Inside') == 0 and
trigger.misc.getUserFlag('MR5-Inside') == 0 and
trigger.misc.getUserFlag('7') == 1 then
mr_text_start()
end


--MR FAIL
if
trigger.misc.getUserFlag('MR1-Inside') == 1 and
trigger.misc.getUserFlag('7') == 1 then
mr_text_fail()
end

if
trigger.misc.getUserFlag('MR2-Inside') == 1 and
trigger.misc.getUserFlag('7') == 1 then
mr_text_fail()
end

if
trigger.misc.getUserFlag('MR3-Inside') == 1 and
trigger.misc.getUserFlag('7') == 1 then
mr_text_fail()
end

if
trigger.misc.getUserFlag('MR4-Inside') == 1 and
trigger.misc.getUserFlag('7') == 1 then
mr_text_fail()
end

if
trigger.misc.getUserFlag('MR5-Inside') == 1 and
trigger.misc.getUserFlag('7') == 1 then
mr_text_fail()
end

--AG Manual
if
trigger.misc.getUserFlag('AG-STARTING') == 0 and
trigger.misc.getUserFlag('AG1-Inside') == 0 and
trigger.misc.getUserFlag('AG2-Inside') == 0 and
trigger.misc.getUserFlag('AG3-Inside') == 0 and
trigger.misc.getUserFlag('AG4-Inside') == 0 and
trigger.misc.getUserFlag('AG5-Inside') == 0 and
trigger.misc.getUserFlag('6') == 1 then
a2gj_text_start()
end


--AG FAIL
if
trigger.misc.getUserFlag('AG1-Inside') == 1 and
trigger.misc.getUserFlag('6') == 1 then
a2gj_text_fail()
end

if
trigger.misc.getUserFlag('AG2-Inside') == 1 and
trigger.misc.getUserFlag('6') == 1 then
a2gj_text_fail()
end

if
trigger.misc.getUserFlag('AG3-Inside') == 1 and
trigger.misc.getUserFlag('6') == 1 then
a2gj_text_fail()
end

if
trigger.misc.getUserFlag('AG4-Inside') == 1 and
trigger.misc.getUserFlag('6') == 1 then
a2gj_text_fail()
end

if
trigger.misc.getUserFlag('AG5-Inside') == 1 and
trigger.misc.getUserFlag('6') == 1 then
a2gj_text_fail()
end

--AG Manual
if
trigger.misc.getUserFlag('AGH-STARTING') == 0 and
trigger.misc.getUserFlag('AGH1-Inside') == 0 and
trigger.misc.getUserFlag('AGH2-Inside') == 0 and
trigger.misc.getUserFlag('AGH3-Inside') == 0 and
trigger.misc.getUserFlag('AGH4-Inside') == 0 and
trigger.misc.getUserFlag('AGH5-Inside') == 0 and
trigger.misc.getUserFlag('AGH6-Inside') == 0 and
trigger.misc.getUserFlag('AGH7-Inside') == 0 and
trigger.misc.getUserFlag('AGH8-Inside') == 0 and
trigger.misc.getUserFlag('AGH9-Inside') == 0 and
trigger.misc.getUserFlag('AGH10-Inside') == 0 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_start()
end


--AG FAIL
if
trigger.misc.getUserFlag('AGH1-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH2-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH3-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH4-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH5-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH6-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH7-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH8-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH9-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end

if
trigger.misc.getUserFlag('AGH10-Inside') == 1 and
trigger.misc.getUserFlag('8') == 1 then
a2gh_text_fail()
end


--AG Manual
if
trigger.misc.getUserFlag('AGH-STARTING') == 0 and
trigger.misc.getUserFlag('AGH1-Inside') == 0 and
trigger.misc.getUserFlag('AGH2-Inside') == 0 and
trigger.misc.getUserFlag('AGH3-Inside') == 0 and
trigger.misc.getUserFlag('AGH4-Inside') == 0 and
trigger.misc.getUserFlag('AGH5-Inside') == 0 and
trigger.misc.getUserFlag('AGH6-Inside') == 0 and
trigger.misc.getUserFlag('AGH7-Inside') == 0 and
trigger.misc.getUserFlag('AGH8-Inside') == 0 and
trigger.misc.getUserFlag('AGH9-Inside') == 0 and
trigger.misc.getUserFlag('AGH10-Inside') == 0 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_start()
end

--AG FAIL
if
trigger.misc.getUserFlag('AGH1-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH2-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH3-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH4-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH5-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH6-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH7-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH8-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH9-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end

if
trigger.misc.getUserFlag('AGH10-Inside') == 1 and
trigger.misc.getUserFlag('10') == 1 then
a2gia_text_fail()
end


--AG Manual
if
trigger.misc.getUserFlag('AS-STARTING') == 0 and
trigger.misc.getUserFlag('ASS1-Inside') == 0 and
trigger.misc.getUserFlag('ASS2-Inside') == 0 and
trigger.misc.getUserFlag('ASS3-Inside') == 0 and
trigger.misc.getUserFlag('ASS4-Inside') == 0 and
trigger.misc.getUserFlag('ASS5-Inside') == 0 and
trigger.misc.getUserFlag('9') == 1 then
a2gas_text_start()
end

--AG FAIL
if
trigger.misc.getUserFlag('ASS1-Inside') == 1 and
trigger.misc.getUserFlag('9') == 1 then
a2gas_text_fail()
end

if
trigger.misc.getUserFlag('ASS2-Inside') == 1 and
trigger.misc.getUserFlag('9') == 1 then
a2gas_text_fail()
end

if
trigger.misc.getUserFlag('ASS3-Inside') == 1 and
trigger.misc.getUserFlag('9') == 1 then
a2gas_text_fail()
end

if
trigger.misc.getUserFlag('ASS4-Inside') == 1 and
trigger.misc.getUserFlag('9') == 1 then
a2gas_text_fail()
end

if
trigger.misc.getUserFlag('ASS5-Inside') == 1 and
trigger.misc.getUserFlag('9') == 1 then
a2gas_text_fail()
end

end

end
main_start_missions()

trigger.action.outText("Trigger LUA File Loaded...", 10)
env.info('TRIGGER LUA FILE LOAD SUCCESSFUL... ok')